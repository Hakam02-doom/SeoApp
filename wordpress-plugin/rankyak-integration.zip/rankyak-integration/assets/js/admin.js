jQuery(document).ready(function($) {
    // Add any admin JavaScript here
    console.log('RankYak Integration admin loaded');
});

